# 🎮 Dev.TicTacToe() — Ultra Pro v4.0

<div align="center">

![Version](https://img.shields.io/badge/version-4.0.0-58a6ff?style=for-the-badge)
![License](https://img.shields.io/badge/license-MIT-3fb950?style=for-the-badge)
![HTML](https://img.shields.io/badge/HTML5-E34F26?style=for-the-badge&logo=html5&logoColor=white)
![CSS](https://img.shields.io/badge/CSS3-1572B6?style=for-the-badge&logo=css3&logoColor=white)
![JavaScript](https://img.shields.io/badge/JavaScript-ES6+-F7DF1E?style=for-the-badge&logo=javascript&logoColor=black)

**A developer-themed, feature-rich Tic-Tac-Toe built with vanilla HTML, CSS, and JavaScript.**  
No frameworks. No build tools. Just open `index.html` and play.

[🐛 Report Bug](../../issues) · [✨ Request Feature](../../issues)

</div>

---

## ✨ Features

| Feature | Details |
|---|---|
| 🗂️ **Board Sizes** | 3×3 · 4×4 · 5×5 — dynamically generated |
| 🎯 **Win Condition** | Choose 3 / 4 / 5 in a row (validated against board size) |
| 👥 **Game Modes** | Player vs Player · Player vs AI |
| 🤖 **AI Difficulty** | Easy (random) · Medium (heuristic) · Hard (Minimax + α-β pruning) |
| 💬 **AI Explains Moves** | Every AI move annotated: `winning move 🏆`, `blocking fork 🔒`, `center control ⚡` |
| 🌲 **Minimax Tree** | Visual evaluation tree after each Hard AI move |
| 🏆 **Tournament Mode** | Best of 3 / 5 with pip tracker and champion banner |
| ⏱️ **Turn Timer** | 30-second countdown — expired turn auto-skips |
| 📋 **Move Log** | Live numbered feed with timestamps |
| 📝 **Git Log** | Conventional-commit history for every game action |
| 😎 **Emoji Avatars** | 25-emoji avatar picker per player |
| ✨ **Animations** | Board stagger intro · pop-in · win glow · confetti |

---

## 🗂️ Project Structure

```
dev-tictactoe/
├── index.html          # HTML skeleton — no inline styles or scripts
├── css/
│   └── main.css        # All styles (CSS variables, layout, animations)
├── js/
│   ├── config.js       # Global TTT namespace, shared state & constants
│   ├── board.js        # Win-combo generation, cell rendering, animations
│   ├── ai.js           # AI engine: Easy / Medium / Hard (Minimax + α-β)
│   ├── confetti.js     # Canvas-based confetti particle system
│   ├── log.js          # Move log, git-style history, tab switching
│   ├── ui.js           # Scoreboard, status, tournament bar, tree panel
│   ├── timer.js        # Per-turn countdown timer
│   ├── game.js         # Core game loop: newGame / playAt / checkResult
│   ├── setup.js        # Setup screen, emoji picker, startGame
│   └── main.js         # Entry point — event bindings, bootstrap
└── README.md
```

---

## 🚀 Getting Started

### Just open it
```bash
git clone https://github.com/YOUR_USERNAME/dev-tictactoe.git
open dev-tictactoe/index.html
```

### Local dev server (optional)
```bash
python -m http.server 8000
# or
npx serve .
```

### GitHub Pages (free hosting)
Go to repo **Settings → Pages → Source: main branch / root** → your game is live at  
`https://YOUR_USERNAME.github.io/dev-tictactoe`

---

## 🧠 Architecture

All modules attach to `window.TTT` — a single namespace — so they can reference each other without circular imports or a bundler.

```
window.TTT
├── cfg        → Game config  (mode, size, winLen, tour, diff)
├── state      → All mutable runtime state
├── Board      → Board generation & DOM management
├── AI         → AI engine + move explanation
├── Confetti   → Canvas particle animation
├── Log        → Move log, git log, tab switching
├── UI         → All display update methods
├── Timer      → Countdown timer
├── Game       → Core game loop
└── Setup      → Setup screen & config
```

---

## 🤖 AI Engine

Hard mode uses **Minimax with Alpha-Beta pruning**, depth-limited by board size for performance. After each move the **ai.tree** panel renders every evaluated position, colour-coded by score. The AI explains every decision in the move log:

```
AI.O → [1,1]  ← center control ⚡
AI.O → [0,2]  ← blocking player win 🛡️
AI.O → [2,0]  ← fork creation ⚔️
AI.O → [1,2]  ← best evaluated (score: +8) 🧠
```

---

## 📄 License

MIT © [Sonu-debug-ui](https://github.com/Sonu-debug-ui)

---

## 👨‍💻 Developer

**Soumyakanta Behera**

[![LinkedIn](https://img.shields.io/badge/LinkedIn-0077B5?style=for-the-badge&logo=linkedin&logoColor=white)](https://www.linkedin.com/in/soumyakanta-behera-b09653313)
[![GitHub](https://img.shields.io/badge/GitHub-100000?style=for-the-badge&logo=github&logoColor=white)](https://github.com/Sonu-debug-ui)

<div align="center"><sub>⭐ Star the repo if you found it useful!</sub></div>
