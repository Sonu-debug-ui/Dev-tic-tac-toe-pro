/**
 * js/setup.js
 * ─────────────────────────────────────────────────────
 * Everything that happens on the setup screen:
 *   • Config option toggles (mode / size / win / tour / diff)
 *   • Win-button sync (disable impossible win lengths)
 *   • Emoji avatar picker modal
 *   • startGame() — validates input, applies CFG, launches game
 *   • goToSetup() — navigate back to the setup screen
 * ─────────────────────────────────────────────────────
 */

'use strict';

TTT.Setup = {

  /* ── Option buttons ─────────────────────────────── */

  /**
   * Toggle an option button group and update TTT.cfg.
   *
   * @param {string} key   - CFG key: 'mode'|'size'|'win'|'tour'|'diff'
   * @param {string} val   - New value (will be coerced to number when numeric)
   * @param {string} color - One of: 'b'|'g'|'o'|'r'|'p'
   */
  setOpt(key, val, color) {
    // Coerce numeric strings
    TTT.cfg[key] = (val !== '' && !isNaN(val)) ? Number(val) : val;

    // Remove all colour classes from siblings, add to selected
    document.querySelectorAll(`[data-k="${key}"]`).forEach(btn => {
      Object.values(TTT.COLOR_MAP).forEach(cls => btn.classList.remove(cls));
    });
    const active = document.querySelector(`[data-k="${key}"][data-v="${val}"]`);
    if (active) active.classList.add(TTT.COLOR_MAP[color]);

    // Side effects per key
    if (key === 'size') this.syncWinButtons();
    if (key === 'mode') this._toggleAIOptions(val);
  },

  /**
   * Disable win-condition buttons that exceed the current board size.
   * Also clamp TTT.cfg.winLen if the active value is now invalid.
   */
  syncWinButtons() {
    const size = TTT.cfg.size;
    document.querySelectorAll('[data-k="win"]').forEach(btn => {
      btn.disabled = Number(btn.dataset.v) > size;
    });

    if (TTT.cfg.winLen > size) {
      TTT.cfg.winLen = size;
      this.setOpt('win', String(size), 'g');
    }
  },

  /** Show/hide AI-specific UI depending on selected game mode. */
  _toggleAIOptions(mode) {
    const isAI = mode === 'ai';
    document.getElementById('diffSection').classList.toggle('hidden', !isAI);
    document.getElementById('cardO').classList.toggle('hidden', isAI);
  },

  /* ── Emoji picker ───────────────────────────────── */

  /**
   * Open the emoji picker modal for a given player.
   *
   * @param {'X'|'O'} player
   */
  openEmojiPicker(player) {
    TTT.state.epTarget = player;
    document.getElementById('epTitle').textContent = `player.${player}.avatar =`;

    const grid = document.getElementById('epGrid');
    grid.innerHTML = '';

    TTT.EMOJIS.forEach(emoji => {
      const btn = document.createElement('button');
      btn.className   = 'ep-btn' + (TTT.avs[player] === emoji ? ' sel' : '');
      btn.textContent = emoji;
      btn.addEventListener('click', () => this._pickEmoji(emoji));
      grid.appendChild(btn);
    });

    document.getElementById('epOverlay').classList.remove('hidden');
  },

  /** Apply the chosen emoji and close the overlay. */
  _pickEmoji(emoji) {
    const player = TTT.state.epTarget;
    TTT.avs[player] = emoji;
    document.getElementById('av' + player).textContent = emoji;
    document.getElementById('epOverlay').classList.add('hidden');
  },

  /** Close the overlay when clicking the dark backdrop. */
  closeEmojiPicker(event) {
    if (event.target === document.getElementById('epOverlay')) {
      document.getElementById('epOverlay').classList.add('hidden');
    }
  },

  /* ── Game start ─────────────────────────────────── */

  /**
   * Read the form values, configure the session, and launch the game.
   * Called by the "▶ game.start()" button.
   */
  startGame() {
    const nameXVal = document.getElementById('nameX').value.trim();
    const nameOVal = document.getElementById('nameO').value.trim();

    TTT.names.X = nameXVal || 'Dev.X';
    TTT.names.O = TTT.cfg.mode === 'ai'
      ? `AI.${TTT.cfg.diff}`
      : (nameOVal || 'Dev.O');

    // AI always uses the robot emoji
    if (TTT.cfg.mode === 'ai') TTT.avs.O = '🤖';

    // Sync player labels in the scoreboard
    TTT.UI.syncPlayerLabels();

    // Update mode description
    const sizeLbl  = `${TTT.cfg.size}×${TTT.cfg.size}`;
    const winLbl   = `${TTT.cfg.winLen}-in-a-row`;
    const tourLbl  = TTT.cfg.tour > 0 ? ` · Best of ${TTT.cfg.tour}` : '';
    const modeLbl  = TTT.cfg.mode === 'ai'
      ? `PvAI · ${TTT.cfg.diff}`
      : 'PvP';
    document.getElementById('modeLabel').textContent =
      `// ${modeLbl} · ${sizeLbl} · ${winLbl}${tourLbl}`;

    // Difficulty badge
    const labels = { easy: '🟢 Easy', medium: '🟡 Medium', hard: '🔴 Hard (Minimax)' };
    document.getElementById('diffBadge').innerHTML = TTT.cfg.mode === 'ai'
      ? `<span class="diff-badge ${TTT.cfg.diff}">${labels[TTT.cfg.diff]}</span>`
      : '';

    // Tournament bar visibility
    const hasTour = TTT.cfg.tour > 0;
    document.getElementById('tBar').classList.toggle('hidden', !hasTour);
    document.getElementById('btnSeries').style.display = hasTour ? '' : 'none';

    // AI tree tab visibility
    const treeBtn = document.getElementById('treeTabBtn');
    treeBtn.classList.toggle('hidden', TTT.cfg.mode !== 'ai');
    if (TTT.cfg.mode !== 'ai' && TTT.state.activeTab === 'tree') {
      TTT.Log.switchTab('log');
    }

    // Reset all session state
    TTT.scores   = { X: 0, O: 0, draw: 0 };
    TTT.series   = { X: 0, O: 0 };
    Object.assign(TTT.state, {
      totalMoves: 0, gamesPlayed: 0, fastestWin: null,
      longestGame: 0, seriesOver: false,
    });

    TTT.Log.clearAll();
    TTT.UI.updateScoreboard();
    TTT.UI.updateTBar();
    TTT.UI.updateStats();
    document.getElementById('champBanner').classList.add('hidden');
    document.getElementById('aiTree').innerHTML =
      '<div class="tree-empty">AI has not moved yet.<br>Tree appears after first Hard move.</div>';

    // Transition screens
    document.getElementById('setupScreen').classList.add('hidden');
    document.getElementById('gameScreen').classList.remove('hidden');

    // Kick off the first game
    TTT.Game.newGame();

    // Opening log messages
    const modeStr = TTT.cfg.mode === 'ai' ? 'lai' : 'lo';
    TTT.Log.sysLog(
      `Session: <span class="lx">${TTT.avs.X} ${TTT.names.X}</span>` +
      ` vs <span class="${modeStr}">${TTT.avs.O} ${TTT.names.O}</span>`,
    );
    TTT.Log.sysLog(
      `${TTT.cfg.size}×${TTT.cfg.size} · ${TTT.cfg.winLen}-in-a-row` +
      (TTT.cfg.tour > 0 ? ` · Best of ${TTT.cfg.tour}` : ''),
    );
    TTT.Log.addCommit(
      'sys',
      `chore: session initialized — ${TTT.names.X} vs ${TTT.names.O}`,
      'system',
    );
    TTT.Log.sep();
  },

  /** Navigate back to the setup screen (preserves current scores). */
  goToSetup() {
    TTT.Timer.stop();
    document.getElementById('gameScreen').classList.add('hidden');
    document.getElementById('setupScreen').classList.remove('hidden');
  },
};
