/**
 * js/confetti.js
 * ─────────────────────────────────────────────────────
 * Self-contained canvas confetti animation.
 * Runs for ~210 frames then clears the canvas automatically.
 *
 * Usage:
 *   TTT.Confetti.launch();
 * ─────────────────────────────────────────────────────
 */

'use strict';

TTT.Confetti = {

  /** Colour palette — mirrors the game's CSS variables */
  _COLORS: [
    '#58a6ff', '#3fb950', '#ff7b72',
    '#79c0ff', '#bc8cff', '#e3b341',
    '#f0f6fc', '#ffa500',
  ],

  /**
   * Launch a burst of confetti particles.
   * Safe to call multiple times (each call starts a fresh animation).
   */
  launch() {
    const canvas = document.getElementById('confetti-canvas');
    const ctx    = canvas.getContext('2d');

    canvas.width  = window.innerWidth;
    canvas.height = window.innerHeight;

    const particles = this._createParticles(130, canvas.width, canvas.height);
    let   frame     = 0;

    const draw = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      for (const p of particles) {
        ctx.save();
        ctx.translate(p.x, p.y);
        ctx.rotate(p.tilt * (Math.PI / 180));
        ctx.fillStyle   = p.color;
        ctx.globalAlpha = 0.88;

        if (p.shape === 'rect') {
          ctx.fillRect(-p.r / 2, -p.r / 2, p.r, p.r * 0.4);
        } else {
          ctx.beginPath();
          ctx.arc(0, 0, p.r / 2, 0, Math.PI * 2);
          ctx.fill();
        }

        ctx.restore();

        // Physics update
        p.y    += p.vy;
        p.x    += p.vx;
        p.tilt += p.tiltSpeed;

        // Wrap vertically
        if (p.y > canvas.height) {
          p.y = -10;
          p.x = Math.random() * canvas.width;
        }
      }

      if (++frame < 210) {
        requestAnimationFrame(draw);
      } else {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
      }
    };

    draw();
  },

  /* ── Private ──────────────────────────────────── */

  /**
   * Generate an array of particle descriptors.
   *
   * @param  {number} count
   * @param  {number} w  - canvas width
   * @param  {number} h  - canvas height
   * @returns {object[]}
   */
  _createParticles(count, w, h) {
    return Array.from({ length: count }, () => ({
      x:         Math.random() * w,
      y:        -10 - Math.random() * 160,
      r:          4 + Math.random() * 7,
      vy:         2.5 + Math.random() * 3,
      vx:        (Math.random() - 0.5) * 2.5,
      color:     this._COLORS[Math.floor(Math.random() * this._COLORS.length)],
      tilt:      Math.random() * 10 - 5,
      tiltSpeed: 0.07 * (Math.random() - 0.5),
      shape:     Math.random() > 0.5 ? 'rect' : 'circle',
    }));
  },
};
