/**
 * js/board.js
 * ─────────────────────────────────────────────────────
 * Handles the game board:
 *   • Generating all valid win combinations for any size/winLen
 *   • Injecting cell <button> elements into the DOM
 *   • Board intro stagger animation
 *   • Checking for a winner
 *   • Highlighting winning cells
 *   • Disabling all cells at game end
 * ─────────────────────────────────────────────────────
 */

'use strict';

TTT.Board = {

  /**
   * Generate every valid winning line for a given board size and
   * win-condition length (e.g. 4×4 board with 3-in-a-row).
   *
   * @param  {number} size   - Board dimension (3 | 4 | 5)
   * @param  {number} winLen - Consecutive marks needed to win
   * @returns {number[][]}   - Array of index arrays
   */
  genCombos(size, winLen) {
    const combos = [];

    // Rows
    for (let r = 0; r < size; r++) {
      for (let c = 0; c <= size - winLen; c++) {
        const line = [];
        for (let i = 0; i < winLen; i++) line.push(r * size + c + i);
        combos.push(line);
      }
    }

    // Columns
    for (let c = 0; c < size; c++) {
      for (let r = 0; r <= size - winLen; r++) {
        const line = [];
        for (let i = 0; i < winLen; i++) line.push((r + i) * size + c);
        combos.push(line);
      }
    }

    // Diagonals: top-left → bottom-right
    for (let r = 0; r <= size - winLen; r++) {
      for (let c = 0; c <= size - winLen; c++) {
        const line = [];
        for (let i = 0; i < winLen; i++) line.push((r + i) * size + c + i);
        combos.push(line);
      }
    }

    // Diagonals: top-right → bottom-left
    for (let r = 0; r <= size - winLen; r++) {
      for (let c = winLen - 1; c < size; c++) {
        const line = [];
        for (let i = 0; i < winLen; i++) line.push((r + i) * size + c - i);
        combos.push(line);
      }
    }

    return combos;
  },

  /**
   * Inject cell buttons into #gameBoard and wire the click listener
   * (only once — subsequent calls reuse the existing listener).
   */
  build() {
    const { size } = TTT.cfg;
    const cellPx = size === 3 ? 100 : size === 4 ? 80 : 65;
    const fsPx   = size === 3 ? '34px' : size === 4 ? '27px' : '21px';
    const gb = document.getElementById('gameBoard');

    gb.style.gridTemplateColumns = `repeat(${size}, ${cellPx}px)`;
    gb.style.gridTemplateRows    = `repeat(${size}, ${cellPx}px)`;
    gb.innerHTML = '';

    for (let i = 0; i < size * size; i++) {
      const btn = document.createElement('button');
      btn.className       = 'cell';
      btn.dataset.idx     = i;
      btn.style.fontSize  = fsPx;
      gb.appendChild(btn);
    }

    // Attach click handler only once
    if (!TTT.state.boardListened) {
      gb.addEventListener('click', e => {
        const cell = e.target.closest('.cell');
        if (!cell) return;
        // Block input during AI turn
        if (TTT.cfg.mode === 'ai' && TTT.state.currentPlayer === 'O') return;
        TTT.Game.handleMove(parseInt(cell.dataset.idx));
      });
      TTT.state.boardListened = true;
    }
  },

  /** Stagger-animate every cell into view (called at game start). */
  animateIntro() {
    document.querySelectorAll('.cell').forEach((cell, i) => {
      cell.style.opacity = '0';
      setTimeout(() => {
        cell.style.opacity = '';
        cell.classList.add('intro');
        cell.addEventListener('animationend', () => cell.classList.remove('intro'), { once: true });
      }, i * 38);
    });
  },

  /**
   * Return the winning player ('X' | 'O') or null.
   *
   * @param  {string[]}  board  - Flat board array
   * @param  {number[][]} combos - Win combinations to check
   * @returns {string|null}
   */
  getWinner(board, combos) {
    for (const combo of combos) {
      const first = board[combo[0]];
      if (first && combo.every(i => board[i] === first)) return first;
    }
    return null;
  },

  /**
   * Return the first winning combo array, or [].
   *
   * @param  {string[]}   board
   * @param  {number[][]} combos
   * @returns {number[]}
   */
  getWinCombo(board, combos) {
    for (const combo of combos) {
      const first = board[combo[0]];
      if (first && combo.every(i => board[i] === first)) return combo;
    }
    return [];
  },

  /** Stagger-highlight the winning cells with a glow animation. */
  highlightWin(combo) {
    combo.forEach((idx, di) => {
      setTimeout(() => {
        const cell = document.querySelector(`.cell[data-idx="${idx}"]`);
        if (cell) cell.classList.add('winning');
      }, di * 80);
    });
  },

  /** Disable all cells (called after game ends). */
  disableAll() {
    document.querySelectorAll('.cell').forEach(c => { c.disabled = true; });
  },
};
