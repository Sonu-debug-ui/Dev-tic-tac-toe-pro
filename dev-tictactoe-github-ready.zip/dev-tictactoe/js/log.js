/**
 * js/log.js
 * ─────────────────────────────────────────────────────
 * All logging concerns:
 *   • game.log  – live move-by-move feed
 *   • git.log   – conventional-commit-style history
 *   • Tab switching between log / git / ai.tree panels
 * ─────────────────────────────────────────────────────
 */

'use strict';

TTT.Log = {

  /* ══ game.log ════════════════════════════════════ */

  /**
   * Append a numbered move entry to the move log.
   *
   * @param {string} html  - Inner HTML for the log text cell
   * @param {number|null} num - Move number (null = system message)
   */
  addMove(html, num) {
    const log  = document.getElementById('moveLog');
    const entry = document.createElement('div');
    entry.className = 'log-e';

    const ts = this.now();

    if (num !== null) {
      TTT.state.logIdx++;
      const count = TTT.state.logIdx;
      document.getElementById('logCount').textContent =
        count + ' move' + (count !== 1 ? 's' : '');

      entry.innerHTML =
        `<span class="log-num">${String(TTT.state.logIdx).padStart(2, '0')}.</span>` +
        `<span class="log-txt">${html}</span>` +
        `<span class="log-ts">${ts}</span>`;
    } else {
      entry.innerHTML =
        `<span class="log-txt">${html}</span>` +
        `<span class="log-ts">${ts}</span>`;
    }

    log.appendChild(entry);
    log.scrollTop = log.scrollHeight;
  },

  /**
   * Append a dimmed system/info line (no move number).
   *
   * @param {string} html
   */
  sysLog(html) {
    const log   = document.getElementById('moveLog');
    const entry = document.createElement('div');
    entry.className = 'log-e';
    entry.innerHTML =
      `<span class="log-txt" style="color:var(--text-dim)">${html}</span>`;
    log.appendChild(entry);
    log.scrollTop = log.scrollHeight;
  },

  /** Append a horizontal rule separator to the move log. */
  sep() {
    const log  = document.getElementById('moveLog');
    const hr   = document.createElement('hr');
    hr.className = 'log-sep';
    log.appendChild(hr);
    log.scrollTop = log.scrollHeight;
  },

  /* ══ git.log ═════════════════════════════════════ */

  /**
   * Prepend a new commit to the git log (newest first).
   *
   * @param {string} type    - Node colour class: 'x'|'o'|'sys'|'win'|'tag'
   * @param {string} message - Commit message body
   * @param {string} author  - Author name shown in meta line
   */
  addCommit(type, message, author) {
    TTT.state.gitTotal++;
    const hash = Math.random().toString(16).substr(2, 7);
    const ts   = this.now();
    const gl   = document.getElementById('gitLog');

    const entry = document.createElement('div');
    entry.className = 'git-c';
    entry.innerHTML =
      `<div class="git-g">
         <div class="git-n ${type}"></div>
         <div class="git-line"></div>
       </div>
       <div class="git-info">
         <div class="git-hash">${hash}</div>
         <div class="git-msg">${message}</div>
         <div class="git-meta">${author} · ${ts}</div>
       </div>`;

    // Newest commit at the top
    gl.insertBefore(entry, gl.firstChild);

    document.getElementById('gitCount').textContent =
      TTT.state.gitTotal + ' commit' + (TTT.state.gitTotal !== 1 ? 's' : '');
  },

  /**
   * Build a conventional commit message string from a move.
   *
   * @param {string}      player      - 'X' | 'O'
   * @param {number}      idx
   * @param {string|null} explanation - Result of AI.explainMove
   * @returns {string}
   */
  gitMsg(player, idx, explanation) {
    const r = Math.floor(idx / TTT.cfg.size);
    const c = idx % TTT.cfg.size;
    const p = player.toLowerCase();

    if (!explanation) return `feat(${p}): play at [${r},${c}]`;

    if (explanation.includes('winning'))          return `fix: clinch victory at [${r},${c}]`;
    if (explanation.includes('blocking player'))  return `fix(defense): block win threat at [${r},${c}]`;
    if (explanation.includes('fork creation'))    return `feat: fork offensive at [${r},${c}]`;
    if (explanation.includes('blocking fork'))    return `fix(defense): neutralize fork at [${r},${c}]`;
    if (explanation.includes('center'))           return `feat: capture center control`;
    if (explanation.includes('corner'))           return `feat: corner acquisition [${r},${c}]`;
    return `feat(${p}): best evaluated position [${r},${c}]`;
  },

  /* ══ Panel tabs ══════════════════════════════════ */

  /**
   * Switch the active tab in the side panel.
   *
   * @param {'log'|'git'|'tree'} tab
   */
  switchTab(tab) {
    TTT.state.activeTab = tab;

    document.querySelectorAll('.tab-btn').forEach(btn => {
      btn.classList.toggle('active', btn.dataset.tab === tab);
    });

    document.getElementById('tabLog') .classList.toggle('active', tab === 'log');
    document.getElementById('tabGit') .classList.toggle('active', tab === 'git');
    document.getElementById('tabTree').classList.toggle('active', tab === 'tree');
  },

  /* ══ Utility ══════════════════════════════════════ */

  /** Return current time as HH:MM:SS string. */
  now() {
    const d = new Date();
    return [d.getHours(), d.getMinutes(), d.getSeconds()]
      .map(v => String(v).padStart(2, '0'))
      .join(':');
  },

  /** Clear both logs and reset counters. */
  clearAll() {
    document.getElementById('moveLog').innerHTML = '';
    document.getElementById('gitLog').innerHTML  = '';
    document.getElementById('logCount').textContent = '0 moves';
    document.getElementById('gitCount').textContent = '0 commits';
    TTT.state.logIdx   = 0;
    TTT.state.gitTotal = 0;
  },
};
