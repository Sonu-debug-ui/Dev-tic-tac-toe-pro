/**
 * js/game.js
 * ─────────────────────────────────────────────────────
 * Core game loop.  Orchestrates all other modules.
 *
 * Responsibilities:
 *   • newGame()       – reset board, rebuild DOM, start timer
 *   • resetAll()      – wipe all scores / logs / stats
 *   • handleMove(i)   – validate then delegate to playAt
 *   • playAt(i, exp)  – update board, DOM, logs, then check result
 *   • checkResult()   – detect win / draw, handle tournament
 *   • handleTimeout() – registered with TTT.Timer.onTimeout
 *   • newSeries()     – reset series scores
 * ─────────────────────────────────────────────────────
 */

'use strict';

TTT.Game = {

  /* ── Session start ──────────────────────────────── */

  /**
   * Begin a brand-new game round.
   * Called on first launch and after each game ends.
   */
  newGame() {
    TTT.Timer.stop();

    // Reset per-game state
    const s          = TTT.cfg.size;
    TTT.state.board  = new Array(s * s).fill('');
    TTT.state.currentPlayer = 'X';
    TTT.state.gameActive    = true;
    TTT.state.moveCount     = 0;
    TTT.state.logIdx        = 0;

    document.getElementById('logCount').textContent = '0 moves';

    // Regenerate win combos (board size / winLen may have changed)
    TTT.state.winCombos = TTT.Board.genCombos(s, TTT.cfg.winLen);

    TTT.Board.build();
    TTT.Board.animateIntro();
    TTT.UI.updateScoreboard();
    TTT.UI.updateStatus();
    TTT.Timer.start();

    TTT.state.gamesPlayed++;
    TTT.UI.updateStats();
  },

  /**
   * Hard reset: wipe all scores, series, logs, and stats,
   * then start a fresh game.
   */
  resetAll() {
    TTT.Timer.stop();

    TTT.scores = { X: 0, O: 0, draw: 0 };
    TTT.series = { X: 0, O: 0 };
    Object.assign(TTT.state, {
      totalMoves: 0, gamesPlayed: 0,
      fastestWin: null, longestGame: 0,
      seriesOver: false,
    });

    TTT.Log.clearAll();
    TTT.UI.updateScoreboard();
    TTT.UI.updateTBar();
    TTT.UI.updateStats();
    document.getElementById('champBanner').classList.add('hidden');
    document.getElementById('aiTree').innerHTML =
      '<div class="tree-empty">AI has not moved yet.</div>';

    this.newGame();
    TTT.Log.sysLog('<span class="ld">reset.all() — zero state restored</span>');
    TTT.Log.addCommit('sys', 'chore: hard reset — all scores zeroed', 'system');
  },

  /* ── Move handling ──────────────────────────────── */

  /**
   * Validate a player's chosen cell and delegate to playAt.
   *
   * @param {number} idx - Flat board index of the clicked cell
   */
  handleMove(idx) {
    if (!TTT.state.gameActive || TTT.state.board[idx] !== '') return;
    this.playAt(idx, null);
  },

  /**
   * Apply a move to the board, update the DOM and logs,
   * then run the result check.
   *
   * @param {number}      idx         - Flat board index
   * @param {string|null} explanation - AI explanation string (or null for human)
   */
  playAt(idx, explanation) {
    const { currentPlayer } = TTT.state;
    const { size }          = TTT.cfg;

    // Update model
    TTT.state.board[idx] = currentPlayer;
    TTT.state.moveCount++;
    TTT.state.totalMoves++;

    // Update cell DOM
    const cell = document.querySelector(`.cell[data-idx="${idx}"]`);
    cell.textContent = currentPlayer;
    cell.classList.add(currentPlayer.toLowerCase(), 'pop');
    cell.disabled = true;

    // Build log entry
    const r   = Math.floor(idx / size);
    const c   = idx % size;
    const cls = currentPlayer === 'X'
      ? 'lx'
      : (TTT.cfg.mode === 'ai' ? 'lai' : 'lo');
    const av  = TTT.avs[currentPlayer];

    const exStr = explanation
      ? ` <span style="color:var(--text-dim);font-size:9px">← ${explanation}</span>`
      : '';

    TTT.Log.addMove(
      `<span class="${cls}">${av} ${TTT.names[currentPlayer]}</span> → [${r},${c}]${exStr}`,
      TTT.state.moveCount,
    );

    TTT.Log.addCommit(
      currentPlayer === 'X' ? 'x' : 'o',
      TTT.Log.gitMsg(currentPlayer, idx, explanation),
      TTT.names[currentPlayer],
    );

    TTT.Timer.reset();
    this.checkResult();
  },

  /* ── Result detection ───────────────────────────── */

  /**
   * Check board for a winner or draw.
   * Handles scoreboard, tournament logic, confetti, and logging.
   */
  checkResult() {
    const { board, winCombos } = TTT.state;
    const winner = TTT.Board.getWinner(board, winCombos);

    if (winner) {
      this._handleWin(winner);
      return;
    }

    if (!board.includes('')) {
      this._handleDraw();
      return;
    }

    // Game continues — switch player
    TTT.state.currentPlayer = TTT.state.currentPlayer === 'X' ? 'O' : 'X';
    TTT.UI.updateStatus();
    TTT.UI.highlightActiveScore();

    // Trigger AI if it's its turn
    if (TTT.cfg.mode === 'ai' && TTT.state.currentPlayer === 'O' && TTT.state.gameActive) {
      setTimeout(() => TTT.AI.move(), 80);
    }
  },

  /* ── Win / draw handlers ────────────────────────── */

  _handleWin(winner) {
    TTT.state.gameActive = false;
    TTT.Timer.stop();

    const combo = TTT.Board.getWinCombo(TTT.state.board, TTT.state.winCombos);
    TTT.Board.highlightWin(combo);
    TTT.Board.disableAll();

    TTT.scores[winner]++;
    TTT.UI.updateScoreboard();

    const isAI  = TTT.cfg.mode === 'ai' && winner === 'O';
    const name  = TTT.names[winner];
    const av    = TTT.avs[winner];

    document.getElementById('gameStatus').innerHTML =
      `<div class="win-box">
         // ${isAI ? 'AI WINS' : 'ALGORITHM VICTORY'}<br>
         ${av} ${name}.win() === true
       </div>`;

    TTT.Log.sep();
    TTT.Log.addMove(
      `<span class="lw">🏆 ${av} ${name} wins in ${TTT.state.moveCount} moves!</span>`,
      null,
    );
    TTT.Log.sep();
    TTT.Log.addCommit('win', `release: ${name} wins in ${TTT.state.moveCount} moves`, name);

    // Update fastest / longest records
    const mc = TTT.state.moveCount;
    if (TTT.state.fastestWin === null || mc < TTT.state.fastestWin) TTT.state.fastestWin = mc;
    if (mc > TTT.state.longestGame) TTT.state.longestGame = mc;
    TTT.UI.updateStats();

    // Tournament
    if (TTT.cfg.tour > 0) {
      TTT.series[winner]++;
      TTT.UI.updateTBar();
      const need = Math.ceil(TTT.cfg.tour / 2);
      if (TTT.series[winner] >= need) {
        TTT.state.seriesOver = true;
        TTT.UI.showChampion(winner);
        TTT.Log.addCommit(
          'tag',
          `tag: v${TTT.series[winner]}.0.0 — ${TTT.names[winner]} wins the series`,
          'tournament',
        );
        TTT.Confetti.launch();
        setTimeout(() => TTT.Confetti.launch(), 600);
        return;
      }
    }

    // Render AI tree if applicable
    if (TTT.cfg.mode === 'ai' && TTT.cfg.diff === 'hard') {
      TTT.UI.renderTree(TTT.state.board.findIndex(
        (v, i) => v === winner && TTT.state.winCombos.some(c => c.includes(i)),
      ));
    }

    TTT.Confetti.launch();
  },

  _handleDraw() {
    TTT.state.gameActive = false;
    TTT.Timer.stop();
    TTT.Board.disableAll();

    TTT.scores.draw++;
    TTT.UI.updateScoreboard();

    document.getElementById('gameStatus').innerHTML =
      `<div class="draw-box">
         // STACK OVERFLOW<br>
         game.result === 'draw'
       </div>`;

    TTT.Log.sep();
    TTT.Log.addMove('<span class="ld">Draw — all positions filled</span>', null);
    TTT.Log.sep();
    TTT.Log.addCommit('sys', 'fix: draw — deadlock reached', 'game engine');

    if (TTT.state.moveCount > TTT.state.longestGame) {
      TTT.state.longestGame = TTT.state.moveCount;
    }
    TTT.UI.updateStats();
  },

  /* ── Timer timeout handler ──────────────────────── */

  /**
   * Called by TTT.Timer when the countdown expires.
   * Skips the current player's turn.
   */
  handleTimeout() {
    if (!TTT.state.gameActive) return;

    TTT.Log.sysLog(
      `<span class="ld">⏱ Timeout: ${TTT.names[TTT.state.currentPlayer]} — turn skipped</span>`,
    );
    TTT.Log.addCommit(
      'sys',
      `fix(timeout): ${TTT.names[TTT.state.currentPlayer]} exceeded time limit`,
      'clock',
    );

    TTT.state.currentPlayer = TTT.state.currentPlayer === 'X' ? 'O' : 'X';
    TTT.UI.updateStatus();
    TTT.Timer.start();

    if (TTT.cfg.mode === 'ai' && TTT.state.currentPlayer === 'O') {
      setTimeout(() => TTT.AI.move(), 80);
    }
  },

  /* ── Tournament ─────────────────────────────────── */

  /** Reset series scores and start a fresh game. */
  newSeries() {
    TTT.series = { X: 0, O: 0 };
    TTT.state.seriesOver = false;
    document.getElementById('champBanner').classList.add('hidden');
    TTT.UI.updateTBar();
    this.newGame();
    TTT.Log.sysLog('<span class="lai">new Series() — series scores reset</span>');
    TTT.Log.addCommit('sys', 'chore: new series started', 'tournament');
  },
};
