/**
 * js/ai.js
 * ─────────────────────────────────────────────────────
 * AI engine for Player vs AI mode.
 *
 * Difficulty levels:
 *   easy   – picks a random empty cell
 *   medium – wins if possible, blocks opponent win, prefers
 *            center/corners, otherwise random
 *   hard   – full minimax with alpha-beta pruning + heuristic
 *            depth-cut for 4×4 / 5×5 boards
 *
 * Public API:
 *   TTT.AI.move()          – triggers the AI's turn after a delay
 *   TTT.AI.explainMove(i)  – returns a human-readable reason string
 * ─────────────────────────────────────────────────────
 */

'use strict';

TTT.AI = {

  /* ── Public entry point ─────────────────────────── */

  /**
   * Trigger the AI's turn.  Waits ~450–750 ms to feel natural,
   * then picks a move, renders the tree (hard mode), and plays.
   */
  move() {
    TTT.Timer.stop();
    const delay = 450 + Math.random() * 300;

    setTimeout(() => {
      if (!TTT.state.gameActive) return;

      let idx;
      TTT.state.treeData = [];

      switch (TTT.cfg.diff) {
        case 'easy':   idx = this._easy();   break;
        case 'medium': idx = this._medium(); break;
        default:       idx = this._minimaxBest(); break;
      }

      const explanation = this.explainMove(idx);
      TTT.Game.playAt(idx, explanation);
      TTT.Timer.start();
    }, delay);
  },

  /* ── Difficulty strategies ──────────────────────── */

  /** Easy: random empty cell. */
  _easy() {
    const empty = TTT.state.board
      .map((v, i) => (v === '' ? i : -1))
      .filter(i => i >= 0);
    return empty[Math.floor(Math.random() * empty.length)];
  },

  /**
   * Medium: win > block > center > corner > random.
   * Does not look ahead more than one move.
   */
  _medium() {
    const { board, winCombos } = TTT.state;
    const size = TTT.cfg.size;

    // Immediate win?
    let m = this._findWinMove(board, 'O', winCombos);
    if (m !== -1) return m;

    // Block player?
    m = this._findWinMove(board, 'X', winCombos);
    if (m !== -1) return m;

    // Center
    const ctr = Math.floor((size * size) / 2);
    if (board[ctr] === '') return ctr;

    // Corners
    const corners = [0, size - 1, size * (size - 1), size * size - 1]
      .filter(i => board[i] === '');
    if (corners.length) return corners[Math.floor(Math.random() * corners.length)];

    return this._easy();
  },

  /**
   * Hard: pick the move with the highest minimax score.
   * Populates TTT.state.treeData for the visualiser.
   */
  _minimaxBest() {
    const board  = [...TTT.state.board];
    const combos = TTT.state.winCombos;
    const moves  = this._relevantMoves(board);
    let best = -Infinity, bestIdx = -1;

    for (const i of moves) {
      board[i] = 'O';
      const score = this._minimax(board, 0, false, -Infinity, Infinity, combos);
      board[i] = '';

      TTT.state.treeData.push({
        idx:   i,
        score,
        r: Math.floor(i / TTT.cfg.size),
        c: i % TTT.cfg.size,
      });

      if (score > best) { best = score; bestIdx = i; }
    }

    // Sort descending so tree renders best moves first
    TTT.state.treeData.sort((a, b) => b.score - a.score);
    return bestIdx;
  },

  /* ── Minimax with alpha-beta pruning ────────────── */

  _minimax(board, depth, isMax, alpha, beta, combos) {
    const winner = TTT.Board.getWinner(board, combos);
    if (winner === 'O') return 100 - depth;
    if (winner === 'X') return depth - 100;

    const limit = this._depthLimit();
    if (!board.includes('') || depth >= limit) return this._heuristic(board, combos);

    const moves = this._relevantMoves(board);

    if (isMax) {
      let best = -Infinity;
      for (const i of moves) {
        board[i] = 'O';
        best = Math.max(best, this._minimax(board, depth + 1, false, alpha, beta, combos));
        board[i] = '';
        alpha = Math.max(alpha, best);
        if (beta <= alpha) break;   // β cut-off
      }
      return best;
    } else {
      let best = Infinity;
      for (const i of moves) {
        board[i] = 'X';
        best = Math.min(best, this._minimax(board, depth + 1, true, alpha, beta, combos));
        board[i] = '';
      beta = Math.min(beta, best);
        if (beta <= alpha) break;   // α cut-off
      }
      return best;
    }
  },

  /**
   * Positional heuristic: score each winning line by how many marks
   * each player has, exponentially weighted by count.
   */
  _heuristic(board, combos) {
    let score = 0;
    for (const combo of combos) {
      const vals  = combo.map(i => board[i]);
      const oCount = vals.filter(v => v === 'O').length;
      const xCount = vals.filter(v => v === 'X').length;
      if (oCount > 0 && xCount === 0) score += Math.pow(4, oCount);
      if (xCount > 0 && oCount === 0) score -= Math.pow(4, xCount);
    }
    return score;
  },

  /* ── Helpers ────────────────────────────────────── */

  /**
   * For large boards, restrict search to cells adjacent to played marks
   * to keep minimax tractable.
   *
   * @param  {string[]} board
   * @returns {number[]} candidate indices
   */
  _relevantMoves(board) {
    const { size } = TTT.cfg;

    // On 3×3, every empty cell is always relevant
    if (size <= 3) return board.map((v, i) => (v === '' ? i : -1)).filter(i => i >= 0);

    const filled = board.map((v, i) => (v !== '' ? i : -1)).filter(i => i >= 0);
    if (!filled.length) return [Math.floor(size * size / 2)];  // first move: center

    const cands = new Set();
    for (const idx of filled) {
      const r = Math.floor(idx / size), c = idx % size;
      for (let dr = -1; dr <= 1; dr++) {
        for (let dc = -1; dc <= 1; dc++) {
          const nr = r + dr, nc = c + dc;
          if (nr >= 0 && nr < size && nc >= 0 && nc < size && board[nr * size + nc] === '') {
            cands.add(nr * size + nc);
          }
        }
      }
    }

    // Always consider center
    const ctr = Math.floor(size * size / 2);
    if (board[ctr] === '') cands.add(ctr);

    return cands.size
      ? [...cands]
      : board.map((v, i) => (v === '' ? i : -1)).filter(i => i >= 0);
  },

  /** Depth limit to keep computation fast on larger boards. */
  _depthLimit() {
    const { size, winLen } = TTT.cfg;
    if (size === 3) return 12;
    if (size === 4) return winLen <= 3 ? 5 : 4;
    return winLen <= 3 ? 3 : 2;
  },

  /**
   * Scan combos for a 1-move win opportunity for `player`.
   * Returns the empty cell index, or -1 if none found.
   *
   * @param  {string[]}   board
   * @param  {string}     player - 'X' | 'O'
   * @param  {number[][]} combos
   * @returns {number}
   */
  _findWinMove(board, player, combos) {
    for (const combo of combos) {
      const mine  = combo.filter(i => board[i] === player);
      const empty = combo.filter(i => board[i] === '');
      if (mine.length === combo.length - 1 && empty.length === 1) return empty[0];
    }
    return -1;
  },

  /**
   * Detect whether playing at `idx` creates ≥2 winning threats
   * (a "fork") for `player`.
   *
   * @param  {string[]}   board  (will be mutated then restored)
   * @param  {number}     idx
   * @param  {string}     player
   * @param  {number[][]} combos
   * @returns {boolean}
   */
  _makesFork(board, idx, player, combos) {
    board[idx] = player;
    let threats = 0;
    for (const combo of combos) {
      const vals  = combo.map(i => board[i]);
      const mine  = vals.filter(v => v === player).length;
      const empty = combo.filter(i => board[i] === '').length;
      if (mine === TTT.cfg.winLen - 1 && empty === 1) threats++;
    }
    board[idx] = '';
    return threats >= 2;
  },

  /* ── Move explanation ───────────────────────────── */

  /**
   * Return a developer-flavoured string explaining why the AI
   * chose this index.  Used in both the move log and tree panel.
   *
   * @param  {number} idx
   * @returns {string}
   */
  explainMove(idx) {
    const { board, winCombos } = TTT.state;
    const { size, winLen }     = TTT.cfg;
    const r = Math.floor(idx / size);
    const c = idx % size;

    // Would this move win?
    const testWin = [...board]; testWin[idx] = 'O';
    if (TTT.Board.getWinner(testWin, winCombos)) return 'winning move 🏆';

    // Would this block a player win?
    const testBlock = [...board]; testBlock[idx] = 'X';
    if (TTT.Board.getWinner(testBlock, winCombos)) return 'blocking player win 🛡️';

    // Fork creation?
    const fb = [...board];
    if (this._makesFork(fb, idx, 'O', winCombos)) return `fork creation [${r},${c}] ⚔️`;

    // Blocking a fork?
    const fb2 = [...board];
    if (this._makesFork(fb2, idx, 'X', winCombos)) return `blocking fork [${r},${c}] 🔒`;

    // Center?
    const ctr = Math.floor(size / 2);
    if (r === ctr && c === ctr) return 'center control ⚡';

    // Corner?
    const corners = [0, size - 1, size * (size - 1), size * size - 1];
    if (corners.includes(idx)) return `corner strategy [${r},${c}] 🎯`;

    // Fall back to minimax score
    const entry = TTT.state.treeData.find(t => t.idx === idx);
    const sc    = entry ? entry.score : 0;
    return `best evaluated (score: ${sc > 0 ? '+' : ''}${sc}) 🧠`;
  },
};
