/**
 * js/ui.js
 * ─────────────────────────────────────────────────────
 * All DOM-update concerns that are not directly board- or
 * log-related:
 *   • Game status message
 *   • Scoreboard & active-player highlight
 *   • Tournament progress bar (pips + score)
 *   • Minimax tree visualiser
 *   • Session stats panel
 *   • Champion banner
 * ─────────────────────────────────────────────────────
 */

'use strict';

TTT.UI = {

  /* ── Convenience shorthand ──────────────────────── */
  $(id) { return document.getElementById(id); },

  /* ── Game status ────────────────────────────────── */

  /**
   * Update the centre status message to reflect whose turn it is.
   * Shows an "AI thinking" indicator when it's the AI's turn.
   */
  updateStatus() {
    if (!TTT.state.gameActive) return;
    const { currentPlayer } = TTT.state;
    const isAITurn = TTT.cfg.mode === 'ai' && currentPlayer === 'O';
    const name     = TTT.names[currentPlayer];
    const av       = TTT.avs[currentPlayer];

    this.$('gameStatus').innerHTML = isAITurn
      ? `<span class="ai-th">
           <span class="d"></span>
           <span class="d"></span>
           <span class="d"></span>
           &nbsp;<span class="lai">${name}.think()</span>
         </span>`
      : `<span class="cur-p">
           ${av} ${name}.move()
           <span style="color:var(--text-dim)"> // awaiting</span>
         </span>`;
  },

  /** Highlight the active player's score card. */
  highlightActiveScore() {
    const p = TTT.state.currentPlayer;
    this.$('sbX').classList.toggle('active-p', p === 'X');
    this.$('sbO').classList.toggle('active-p', p === 'O');
  },

  /* ── Scoreboard ─────────────────────────────────── */

  /** Sync score display with TTT.scores. */
  updateScoreboard() {
    this.$('scX').textContent = TTT.scores.X;
    this.$('scO').textContent = TTT.scores.O;
    this.$('scD').textContent = TTT.scores.draw;
  },

  /**
   * Push player names and avatars into the scoreboard labels.
   * Called once when a session starts.
   */
  syncPlayerLabels() {
    this.$('scLblX').textContent = TTT.names.X;
    this.$('scLblO').textContent = TTT.names.O;
    this.$('scAvX').textContent  = TTT.avs.X;
    this.$('scAvO').textContent  = TTT.avs.O;
  },

  /* ── Tournament bar ─────────────────────────────── */

  /** Render the pip-based series progress (hidden when tour === 0). */
  updateTBar() {
    if (TTT.cfg.tour === 0) return;

    const need = Math.ceil(TTT.cfg.tour / 2);
    this.$('tSc').textContent   = `${TTT.series.X} – ${TTT.series.O}`;
    this.$('tNeed').textContent = `Need ${need} to win`;

    this._renderPips('tPX', need, TTT.series.X, 'wx');
    this._renderPips('tPO', need, TTT.series.O, 'wo');
  },

  /** Render `need` pips, filling the first `won` with the win class. */
  _renderPips(containerId, need, won, winClass) {
    const container = this.$(containerId);
    container.innerHTML = '';
    for (let i = 0; i < need; i++) {
      const pip = document.createElement('div');
      pip.className = 't-pip' + (i < won ? ` ${winClass}` : '');
      pip.textContent = i < won ? '✓' : '';
      container.appendChild(pip);
    }
  },

  /* ── Champion banner ────────────────────────────── */

  /**
   * Show the champion banner for the series winner.
   *
   * @param {string} winner - 'X' | 'O'
   */
  showChampion(winner) {
    const opp  = winner === 'X' ? 'O' : 'X';
    this.$('champText').textContent =
      `🏆 ${TTT.avs[winner]} ${TTT.names[winner]} — Series Champion!`;
    this.$('champSub').textContent  =
      `Won ${TTT.series[winner]}–${TTT.series[opp]} · Best of ${TTT.cfg.tour}`;
    this.$('champBanner').classList.remove('hidden');
  },

  /* ── Minimax tree visualiser ────────────────────── */

  /**
   * Render the minimax evaluation tree panel after an AI Hard move.
   *
   * @param {number} chosenIdx - The index the AI actually played
   */
  renderTree(chosenIdx) {
    const pane = this.$('aiTree');

    if (!TTT.state.treeData.length) {
      pane.innerHTML = '<div class="tree-empty">No candidates evaluated.</div>';
      return;
    }

    const top = TTT.state.treeData.slice(0, Math.min(7, TTT.state.treeData.length));
    let html  = '';

    // Root node
    html += `<div class="tree-root">
               <div class="tree-root-node">
                 🤖 AI evaluates ${TTT.state.treeData.length}
                 position${TTT.state.treeData.length !== 1 ? 's' : ''}
               </div>
             </div>
             <div class="tree-v-line"></div>
             <div class="tree-branches">`;

    for (const n of top) {
      const isBest = n.idx === chosenIdx;
      let nodeClass = 'tree-node';
      if (isBest)       nodeClass += ' best';
      else if (n.score >  5) nodeClass += ' good';
      else if (n.score < -5) nodeClass += ' bad';
      else                   nodeClass += ' mid';

      const scColor = n.score > 0
        ? 'var(--green)' : n.score < 0
        ? 'var(--red)'   : 'var(--text-dim)';

      html += `<div class="tree-branch">
                 <div class="tree-conn"></div>
                 <div class="${nodeClass}">
                   <div class="tn-pos">[${n.r},${n.c}]</div>
                   <div class="tn-sc" style="color:${scColor}">
                     ${n.score > 0 ? '+' : ''}${n.score}
                   </div>
                   ${isBest ? '<div class="tn-lbl" style="color:var(--green)">CHOSEN ✓</div>' : ''}
                 </div>
               </div>`;
    }

    html += `</div>`;

    // Reasoning footer
    const reason = TTT.AI.explainMove(chosenIdx);
    html += `<div class="tree-explain">💡 Reasoning: ${reason}</div>`;

    // Legend
    html += `<div class="tree-legend">
               <span style="color:var(--green)">■ AI advantage</span>
               <span style="color:var(--blue)">■ Slight edge</span>
               <span style="color:var(--orange)">■ Neutral</span>
               <span style="color:var(--red)">■ Danger</span>
             </div>`;

    pane.innerHTML = html;

    // Flash the tree tab label if user isn't already on it
    if (TTT.state.activeTab !== 'tree') {
      const btn = this.$('treeTabBtn');
      btn.style.color = 'var(--green)';
      setTimeout(() => { btn.style.color = ''; }, 1200);
    }
  },

  /* ── Session stats ──────────────────────────────── */

  /** Sync the session stats mini-panel with current state values. */
  updateStats() {
    const { gamesPlayed, totalMoves, fastestWin, longestGame } = TTT.state;
    this.$('stG').textContent = gamesPlayed;
    this.$('stM').textContent = totalMoves;
    this.$('stF').textContent = fastestWin  !== null ? fastestWin  + 'm' : '—';
    this.$('stL').textContent = longestGame > 0      ? longestGame + 'm' : '—';
  },
};
