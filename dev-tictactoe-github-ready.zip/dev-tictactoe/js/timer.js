/**
 * js/timer.js
 * ─────────────────────────────────────────────────────
 * Per-turn countdown timer.
 *
 * When the countdown reaches zero, `TTT.Timer.onTimeout()`
 * is called.  Game.js sets this callback to avoid a circular
 * dependency between timer.js and game.js.
 *
 * Public API:
 *   TTT.Timer.start()       – begin/restart from TIMER_MAX
 *   TTT.Timer.stop()        – clear the interval
 *   TTT.Timer.reset()       – stop then start (used after each move)
 *   TTT.Timer.onTimeout     – set by game.js before the first game
 * ─────────────────────────────────────────────────────
 */

'use strict';

TTT.Timer = {

  /** Callback invoked when the clock hits zero. Set by game.js. */
  onTimeout: null,

  /* ── Public API ─────────────────────────────────── */

  /** Start counting down from TIMER_MAX. */
  start() {
    TTT.timer.left = TTT.TIMER_MAX;
    this._render();

    TTT.timer.id = setInterval(() => {
      TTT.timer.left--;
      this._render();

      if (TTT.timer.left <= 0) {
        clearInterval(TTT.timer.id);
        TTT.timer.id = null;
        if (typeof this.onTimeout === 'function') this.onTimeout();
      }
    }, 1000);
  },

  /** Clear the active interval without resetting the display. */
  stop() {
    if (TTT.timer.id !== null) {
      clearInterval(TTT.timer.id);
      TTT.timer.id = null;
    }
  },

  /** Stop and immediately restart from TIMER_MAX. */
  reset() {
    this.stop();
    this.start();
  },

  /* ── Private ────────────────────────────────────── */

  /** Update the numeric label and progress bar. */
  _render() {
    const pct = (TTT.timer.left / TTT.TIMER_MAX) * 100;
    const bar  = document.getElementById('tTimerBar');

    document.getElementById('tTimerNum').textContent = TTT.timer.left;
    bar.style.width = pct + '%';
    bar.classList.toggle('warn', TTT.timer.left <= 10);
  },
};
