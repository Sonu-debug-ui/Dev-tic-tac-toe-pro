/**
 * js/config.js
 * ─────────────────────────────────────────────────────
 * Initialises the TTT namespace and defines all shared
 * state, configuration objects, and constants.
 *
 * Every other module reads / writes TTT.cfg, TTT.state, etc.
 * ─────────────────────────────────────────────────────
 */

'use strict';

window.TTT = {};

/* ── Constants ──────────────────────────────────────── */

TTT.EMOJIS = [
  '👨‍💻','🦊','🐱','🦅','🐉','🤖','👾','🦁','🐺','🎯',
  '⚡','🔥','💎','🚀','🎭','🦄','🌊','🎪','🦂','🌟',
  '🐸','🧠','👻','🐨','🦖',
];

TTT.TIMER_MAX = 30;

/** Maps setup option key → active CSS class suffix */
TTT.COLOR_MAP = { b: 'ab', g: 'ag', o: 'ao', r: 'ar', p: 'ap' };

/* ── Game Configuration (mutated by Setup) ──────────── */

TTT.cfg = {
  mode:   'pvp',   // 'pvp' | 'ai'
  size:   3,       // 3 | 4 | 5
  winLen: 3,       // 3 | 4 | 5
  tour:   0,       // 0 | 3 | 5
  diff:   'easy',  // 'easy' | 'medium' | 'hard'
};

/* ── Per-session mutable state ──────────────────────── */

TTT.state = {
  board:           [],
  currentPlayer:   'X',
  gameActive:      false,
  winCombos:       [],
  moveCount:       0,
  totalMoves:      0,
  gamesPlayed:     0,
  fastestWin:      null,
  longestGame:     0,
  logIdx:          0,
  gitTotal:        0,
  treeData:        [],
  seriesOver:      false,
  activeTab:       'log',
  epTarget:        null,
  boardListened:   false,
};

TTT.scores = { X: 0, O: 0, draw: 0 };
TTT.series = { X: 0, O: 0 };
TTT.names  = { X: 'Dev.X', O: 'Dev.O' };
TTT.avs    = { X: '👨‍💻',   O: '🦊' };

/* Timer state */
TTT.timer = { id: null, left: TTT.TIMER_MAX };
