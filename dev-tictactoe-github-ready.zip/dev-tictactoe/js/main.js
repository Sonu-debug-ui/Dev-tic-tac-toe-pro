/**
 * js/main.js
 * ─────────────────────────────────────────────────────
 * Application entry point.
 *
 * Runs after all other scripts have loaded.
 * Responsibilities:
 *   • Wire the timer's timeout callback (breaks circular dep)
 *   • Bind all button and input event listeners
 *   • Run one-time initialisations
 *   • Print console welcome message
 * ─────────────────────────────────────────────────────
 */

'use strict';

(function bootstrap() {

  /* ── Wire timer → game callback ─────────────────── */

  // Avoids a circular dependency between timer.js and game.js
  TTT.Timer.onTimeout = function () {
    TTT.Game.handleTimeout();
  };

  /* ── Setup screen ───────────────────────────────── */

  // Option button groups — delegate from each container
  document.querySelectorAll('.btn-group').forEach(group => {
    group.addEventListener('click', e => {
      const btn = e.target.closest('.opt');
      if (!btn || btn.disabled) return;

      const key = btn.dataset.k;
      const val = btn.dataset.v;

      // Determine which colour class to use
      const colorMap = { mode: 'b', size: 'b', win: 'g', tour: 'p', diff: _diffColor(val) };
      TTT.Setup.setOpt(key, val, colorMap[key] || 'b');
    });
  });

  function _diffColor(val) {
    return { easy: 'g', medium: 'o', hard: 'r' }[val] || 'g';
  }

  // Avatar click → open emoji picker
  document.getElementById('avX').addEventListener('click', () => TTT.Setup.openEmojiPicker('X'));
  document.getElementById('avO').addEventListener('click', () => TTT.Setup.openEmojiPicker('O'));

  // Emoji overlay — close on backdrop click
  document.getElementById('epOverlay').addEventListener('click', e => TTT.Setup.closeEmojiPicker(e));

  // Start game button
  document.getElementById('startBtn').addEventListener('click', () => TTT.Setup.startGame());

  // Allow pressing Enter in either name field to start
  ['nameX', 'nameO'].forEach(id => {
    document.getElementById(id).addEventListener('keydown', e => {
      if (e.key === 'Enter') TTT.Setup.startGame();
    });
  });

  /* ── Game screen controls ───────────────────────── */

  document.getElementById('btnNew')   .addEventListener('click', () => TTT.Game.newGame());
  document.getElementById('btnReset') .addEventListener('click', () => TTT.Game.resetAll());
  document.getElementById('btnConfig').addEventListener('click', () => TTT.Setup.goToSetup());
  document.getElementById('btnSeries').addEventListener('click', () => TTT.Game.newSeries());

  // Panel tab buttons
  document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.addEventListener('click', () => TTT.Log.switchTab(btn.dataset.tab));
  });

  /* ── One-time initialisations ───────────────────── */

  // Sync win buttons to the default board size (3×3)
  TTT.Setup.syncWinButtons();

  /* ── Console welcome ────────────────────────────── */

  console.log('%c🎮 Dev.TicTacToe() v4.0.0 — Ultra Pro',
    'color:#58a6ff;font-size:16px;font-weight:bold;');

  const checks = [
    '✓ Modular architecture (9 JS files + CSS + HTML)',
    '✓ Dynamic board: 3×3 | 4×4 | 5×5',
    '✓ Custom win condition (3 | 4 | 5 in a row)',
    '✓ Tournament mode: Best of 3 / 5',
    '✓ AI: Easy · Medium · Hard (Minimax + α-β pruning)',
    '✓ AI explains every move in the log',
    '✓ Live minimax tree visualiser',
    '✓ Git-style commit history',
    '✓ Per-turn countdown timer',
    '✓ Emoji avatar picker',
    '✓ Board intro animation + confetti',
  ];

  checks.forEach(msg => console.log(`%c${msg}`, 'color:#3fb950;'));
  console.log('%cDeveloped by: Sonu-debug-ui', 'color:#f0f6fc;');

})();
