# Contributing to Dev.TicTacToe()

Thanks for your interest! Here's how to contribute.

## Getting Started

1. Fork the repository
2. Clone your fork: `git clone https://github.com/YOUR_USERNAME/dev-tictactoe.git`
3. Open `index.html` in your browser — no build step needed

## Making Changes

- Each JS module lives in `js/` and attaches to `window.TTT`
- All styles are in `css/main.css` using CSS custom properties
- Keep each module focused on its single responsibility
- Test in Chrome, Firefox, and Safari before submitting

## Submitting a Pull Request

1. Create a branch: `git checkout -b feature/your-feature-name`
2. Commit using conventional commits: `feat:`, `fix:`, `chore:`, `docs:`
3. Push and open a PR against `main`
4. Describe what you changed and why

## Reporting Bugs

Open an issue with:
- Browser and OS
- Steps to reproduce
- Expected vs actual behaviour
